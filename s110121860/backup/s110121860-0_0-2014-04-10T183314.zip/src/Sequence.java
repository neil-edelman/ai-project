package s110121860;
/* package halma.CCMove; <- "is not public in halma.CCMove; cannot be accessed
 from outside package;" java packages; why do you have to be so confusing? */

import java.awt.Point;

import halma.CCBoard;
import halma.CCMove;

/** a sequence of CCMove moves */
class Sequence {

	/* constants */
	private static final int size      = CCBoard.SIZE /* 16 */;
	private static final int[][] moves = {{1, 1}, {1, 0}, {1, -1}, {0, -1}, {-1, -1}, {-1, 0}, {-1, 1}, {0, 1}};

	/* "globals" */
	private static boolean isVisited[][] = new boolean[size][size];
	private static Point to              = new Point();
	private static int playerID;
	private static CCBoard board;

	/* class variables */
	private Sequence parent;
	private int height;
	private Point here      = new Point();
	/* private CCMove buffer[] = new CCMove[8]; :[ */
	private CCMove move[]   = new CCMove[8];

	/** cool sol'n but needs constant malloc/free;
	 fixme: have a pool of Sequences that gets allocated once
	 it is really stupid having the playerID everywhere, you don't even use it */
	private Sequence(final Sequence parent, final Point point) {
		/* allocate */
		//for(int i = 0; i < 8; i++) buffer[i] = new CCMove(playerID, new Point(), new Point()); :[
		/* fill in */
		this.parent = parent;
		/* visit it */
		this.here.x = point.x;
		this.here.y = point.y;
		this.height = 0;//hill[here.y][here.x];
		/* get neighbors (sets move[]) */
		isVisited[here.y][here.x] = true;
		getAdjacent(point, 2);
		/* recurse in all (8) directions */
		for(int i = 0; i < 8; i++) {
			if(move[i] == null) continue;
			new Sequence(this, move[i].getTo());
		}
	}
	
	/** which move is best starting at start
	 @param start
	 @param player_id the id of the player
	 @return a sequence of moves */
	public static int best(Point start, final CCBoard ccboard, final int player_id) {

		playerID = player_id;
		board    = ccboard;
		/* clear out all isVisited */
		for(int y = 0; y < size; y++) {
			for(int x = 0; x < size; x++) {
				isVisited[y][x] = false;
			}
		}

		new Sequence((Sequence)null, start);
		return 0;
	}
	
	/** fills the move[]
	 @param from  the point that you want the adjecent
	 @param steps the 'steps' neighbor */
	private void getAdjacent(final Point from, final int steps) {
		CCMove consider;
		int dx, dy;

		for(int i = 0; i < 8; i++) {
			dx = moves[i][0];
			dy = moves[i][1];
			to.x = from.x + steps * dx;
			to.y = from.y + steps * dy;
			/* the only way to access it is from the constructor :[ */
			consider = new CCMove(playerID, from, to);
			if(board.isLegal(consider) && !isVisited[to.y][to.x]) {
				/*move[i] = buffer[i];
				move[i].from.x = from.x;
				move[i].from.y = from.y;
				move[i].x = to.x;
				move[i].y = to.y; :[ */
				move[i] = new CCMove(playerID, from, to); /* :{{{ */
				isVisited[to.y][to.x] = true;
			} else {
				move[i] = null;
			}
		}
		
	}
}
