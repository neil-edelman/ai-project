/** @author Neil */

package s110121860;

/* import java stuff */
import java.util.Random;

/* import game stuff */
import java.util.ArrayList; /* used in CCBoard as a return type */
import boardgame.Board;
import java.awt.Point;      /* used in CCMove as a return type */
import boardgame.Move;
import boardgame.Player;
import halma.CCBoard;
import halma.CCMove;

/** such confusion */
public class s110121860Player extends Player {

	enum Corner {
		TOP_RIGHT,
		TOP_LEFT,
		BOTTOM_LEFT,
		BOTTOM_RIGHT,
	};

	/* the board is n x n (I assume the real variable is somewhere in the
	 bowels of the code, but I do not want to go searching though it) */
	private static final int n = 16;

	/* working dynimic variables */
	private static Point a = new Point(), b = new Point();
	private static Random rand = new Random();

	/* convenient things */
	private int    move = 0;
	private Corner corner;
	private Corner ally;
	private int heuristic[][] = new int[n][n];

	/** agent constructor with no args */
	public s110121860Player() {
		this("110121860");
	}

	/** agent constructor */
	public s110121860Player(String s) {
		super(s);
		switch(playerID) {
			case 0:
				corner = Corner.TOP_LEFT;
				ally = Corner.BOTTOM_RIGHT;
				break;
			case 1:
				corner = Corner.BOTTOM_LEFT;
				ally   = Corner.TOP_RIGHT;
				break;
			case 2:
				corner = Corner.TOP_RIGHT;
				ally   = Corner.BOTTOM_LEFT;
				break;
			case 3:
				corner = Corner.BOTTOM_RIGHT;
				ally   = Corner.TOP_LEFT;
				break;
		}
		fillLuts();
		System.err.print("Cool player on " + corner + " allied with " + ally + ".\n");
		a.x = 3;
		a.y = 4;
		b.x = 10;
		b.y = 3;
		manhattan(a, b);
	}

	private static int manhattan(final Point a, final Point b) {
		int d = 0;
		d += (a.x < b.x) ? b.x - a.x : a.x - b.x;
		d += (a.y < b.y) ? b.y - a.y : a.y - b.y;
		//System.err.print("("+a.x+","+a.y+")-("+b.x+","+b.y+")="+d+"\n");
		return d;
	}

	private void fillLuts() {
		/* the Manhattan distance to the goal */
		switch(corner) {
			case TOP_LEFT:
				a.x = 0;
				a.y = 0;
				break;
			case BOTTOM_LEFT:
				a.x = 0;
				a.y = n - 1;
				break;
			case TOP_RIGHT:
				a.x = n - 1;
				a.y = 0;
				break;
			case BOTTOM_RIGHT:
				a.x = n - 1;
				a.y = n - 1;
				break;
		}
		for(int y = 0; y < n; y++) {
			for(int x = 0; x < n; x++) {
				b.x = x;
				b.y = y;
				heuristic[y][x] = manhattan(a, b);
				System.err.printf("%3d", heuristic[y][x]);
			}
			System.err.printf("\n");
		}
	}

	/** do something mysterious */
	public Board createBoard() {
		return new CCBoard();
	}

	/** the agent */
	public Move chooseMove(Board theboard) {
		Point from, to;
		CCMove best = null;
		int bestDelta = 0, delta;

		/* this is sketchy */
		CCBoard board = (CCBoard)theboard;

		/* get all moves */
		ArrayList<CCMove> moves = board.getLegalMoves();

		System.err.print("\nChoice of moves for player " + corner + " (#" + playerID + "):\n");

		/* output */
		for(CCMove move : moves) {
			from = move.getFrom();
			to   = move.getTo();
			delta = this.heuristic[to.y][to.x] - this.heuristic[from.y][from.x];
			if(bestDelta < delta) {
				bestDelta = delta;
				best = move;
				System.err.print("the best so far ");
			}
			//System.err.print(move.getPlayer_id() + ": " + (P2D)from + "->" + to + ".\n");
			System.err.print("(" + from.x + ", " + from.y + ") -> (" + to.x + ", " + to.y + ") [" + delta + "]\n");
			//System.err.print(move.toPrettyString() + " (" + delta + ")\n");
		}

		/* FIXME: uhhh, the null move is a very valid move, but it balks;
		 hopefully it doesn't matter */
		return best;
		// Return a randomly selected move.
		// return (CCMove) moves.get(0/*rand.nextInt(moves.size())*/);
	}

	/** this is to not crash? */
	public Move choseMove() {
		return null;
	}
}

/** no */
class P2D extends Point {
	@Override
	public String toString() {
		return "(" + x + "," + y + ")";
	}
}
